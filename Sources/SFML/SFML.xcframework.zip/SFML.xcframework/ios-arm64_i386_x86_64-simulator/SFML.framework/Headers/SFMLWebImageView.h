// Copyright (c) 2013 Wishabi. All rights reserved.

#import <UIKit/UIKit.h>

@protocol SFMLImageDownloadTaskProvider;

typedef NS_ENUM(NSInteger, SFMLWebImageViewAspectFillOrigin) {
  SFMLWebImageViewAspectFillOriginCenter = 0,
  SFMLWebImageViewAspectFillOriginTopLeft = 1
};

@interface SFMLWebImageView : UIImageView

@property (nonatomic,strong) NSURL *imageURL;
@property (nonatomic,assign) SFMLWebImageViewAspectFillOrigin aspectFillOrigin;
@property (nonatomic,weak) id<SFMLImageDownloadTaskProvider> imageDownloadTaskProvider;

// SFMLImageLoading
- (instancetype)initWithImageDownloadTaskProvider:(id<SFMLImageDownloadTaskProvider>)provider;

- (void)setImageWithURL:(NSURL *)url
                success:(void (^)(UIImage *))success;

@end
