
//  Copyright © 2017 Flipp. All rights reserved.

#import <UIKit/UIKit.h>

@interface NSLayoutConstraint(SFML)

/**
 *  Stacks views in the given direction with given spacing and insets.
 *  Only returns constraints for the one direction given.
 *
 *  @param views         Array of views to stack
 *  @param direction     The direction.
 *  @param containerView The superview of all the given views.
 *  @param spacing       Array of (views.count - 1) NSNumbers representing space values.
 *  @param insets        Insets for the superview-to-first/last-view.
 *  @param equalSize     If the views being stacked should be equal size.
 *  @param edgeToPin     UIRectEdge wrapped in an NSNumber. Must match direction of `direction`.
                         nil to pin to both sides.
 *
 *  @return Array of NSLayoutConstraints.
 */
+ (NSArray<NSLayoutConstraint *> *)sfml_stackViews:(NSArray<UIView *> *)views
                                         direction:(UILayoutConstraintAxis)direction
                                            inView:(UIView *)containerView
                                individualSpacings:(NSArray<NSNumber *> *)spacing
                                            insets:(UIEdgeInsets)insets
                                         equalSize:(BOOL)equalSize
                                      pinnedToEdge:(NSNumber *)edgeToPin;

+ (NSArray<NSLayoutConstraint *> *)sfml_stackViews:(NSArray<UIView *> *)views
                                         direction:(UILayoutConstraintAxis)direction
                                            inView:(UIView *)containerView
                                           spacing:(CGFloat)spacing
                                            insets:(CGFloat)inset
                                         equalSize:(BOOL)equalSize;

@end
